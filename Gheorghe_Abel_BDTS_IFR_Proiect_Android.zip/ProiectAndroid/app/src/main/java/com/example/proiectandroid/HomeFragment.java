package com.example.proiectandroid;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class HomeFragment extends Fragment {
    private RecyclerView mRecyclerView;
    private ItemAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        ArrayList<RecyclerViewItem> itemList = new ArrayList<>();
        itemList.add(new RecyclerViewItem(R.drawable.ic_baseline_home_24, "Home", "This is Home item"));
        itemList.add(new RecyclerViewItem(R.drawable.ic_baseline_android_24, "Android", "This is Android item"));
        itemList.add(new RecyclerViewItem(R.drawable.ic_baseline_photo_camera_24, "Camera", "This is Camera item"));
        itemList.add(new RecyclerViewItem(R.drawable.ic_baseline_share_24, "Share", "This is Share item"));
        itemList.add(new RecyclerViewItem(R.drawable.ic_baseline_account_circle_24, "Account", "This is Account item"));
        itemList.add(new RecyclerViewItem(R.drawable.ic_baseline_location_on_24, "Location", "This is Location item"));
        itemList.add(new RecyclerViewItem(R.drawable.ic_baseline_flash_on_24, "Flash", "This is Flash item"));
        itemList.add(new RecyclerViewItem(R.drawable.ic_baseline_directions_bus_24, "Bus", "This is Bus item"));

        View view = inflater.inflate(R.layout.fragment_home, container, false);

        mRecyclerView = view.findViewById(R.id.recyclerView);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mAdapter = new ItemAdapter(itemList);

        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);

        return view;
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {

        inflater = getActivity().getMenuInflater();
        inflater.inflate(R.menu.search_menu, menu);
        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) searchItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                mAdapter.getFilter().filter(newText);
                return false;
            }
        });
        super.onCreateOptionsMenu(menu, inflater);
    }
}

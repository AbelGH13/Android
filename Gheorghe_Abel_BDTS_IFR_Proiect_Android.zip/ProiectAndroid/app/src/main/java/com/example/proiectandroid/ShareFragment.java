package com.example.proiectandroid;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ShareFragment extends Fragment {

    private EditText mEditText;
    private Button mShareButton;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_share, container, false);

        mEditText = (EditText) view.findViewById(R.id.plain_text_input);
        mShareButton = (Button) view.findViewById(R.id.shareText_button);
        mShareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sharedText = "Nimic...";
                if(!TextUtils.isEmpty(mEditText.getText().toString())) {
                    sharedText = mEditText.getText().toString();
                    Intent mSharingIntent = new Intent(Intent.ACTION_SEND);
                    mSharingIntent.setType("text/plain");
                    mSharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Write your subject here");
                    mSharingIntent.putExtra(Intent.EXTRA_TEXT, sharedText);
                    startActivity(Intent.createChooser(mSharingIntent, "Share text via"));
                }
                else Toast.makeText(getActivity(), "Please insert text!", Toast.LENGTH_SHORT).show();
            }
        });

        return view;

    }
}
